
# colours
import os

import pygame

red = 255, 0, 0
green = 25, 255, 64
black = 0, 0, 0
blue = 0, 0, 255
yellow = 255, 255, 0
orange = 255, 127, 0
purple = 75, 0, 130
white = 255, 255, 255

maxy = 1000
maxx = 1000
block_size = 20

banned_fruit_spots = [[round(maxx/ 2), round(maxy/ 2)], [round(maxx/ 2), round(maxy/ 2 + block_size)], [round(maxx/ 2), round(maxy/ 2 - block_size)], [round(maxx/ 2 + block_size), round(maxy/ 2)], [round(maxx/ 2 - block_size), round(maxy/ 2)], \
                      ]

pygame.init()  # Initiates import pygame#

base_path = os.path.join(os.path.dirname(__file__), "..")

appleimg = pygame.image.load(os.path.join(base_path, "Textures/apple20.png"))
lemonimg = pygame.image.load(os.path.join(base_path, "Textures/lemon20.png"))
limeimg = pygame.image.load(os.path.join(base_path, "Textures/lime20.png"))
plumimg = pygame.image.load(os.path.join(base_path, "Textures/plum20.png"))

music = pygame.mixer.Sound(os.path.join(base_path, "Sounds/Snek_Background.wav"))
eat = pygame.mixer.Sound(os.path.join(base_path, 'Sounds/Snek_Eat.wav'))
menu_music = pygame.mixer.Sound(os.path.join(base_path, 'Sounds/Snek_Menu.wav'))
click = pygame.mixer.Sound(os.path.join(base_path, 'Sounds/Snek_Click.wav'))
heck = pygame.mixer.Sound(os.path.join(base_path, 'Sounds/Snek_Heck.wav'))

# add icon to game window3
icon = pygame.image.load(os.path.join(base_path, "Textures/snake_icon.png"))
pygame.display.set_icon(icon)
clock = pygame.time.Clock()  # imports the clock

screen = pygame.display.set_mode((maxx, maxy), vsync=True)  # sets screen size
pygame.display.set_caption("Snek")  # sets the name to display at the top
