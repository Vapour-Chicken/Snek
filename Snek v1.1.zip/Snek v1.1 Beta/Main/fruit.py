import random
from dataclasses import dataclass
from typing import List

from pygame import Surface

from Main.globals import *


@dataclass
class Fruit:
    x: int
    y: int
    kind: int

    def __init__(self, snakes: (List, List, List, List)):
        while True:
            x = round(random.randrange(0, maxx - block_size) / block_size) * block_size
            y = round(random.randrange(0, maxy - block_size) / block_size) * block_size
            point = [x, y]
            print(f"point {point}")
            print(f"spots {banned_fruit_spots}")
            if len([point for snake in snakes if point in snake]) == 0 and len([point for banned_fruit_spot in banned_fruit_spots if point in banned_fruit_spot]) == 0:
                self.x = x
                self.y = y
                self.kind = random.randint(0, 3)
                break

    def image(self) -> Surface:
        images = [appleimg, lemonimg, limeimg, plumimg]
        return images[self.kind]

    def energy(self, level: int) -> int:
        food_multi = [1, 2, 4, 8, 8]
        return food_multi[level] * (self.kind + 1)

    def draw(self, screen: Surface):
        screen.blit(self.image(), (self.x, self.y))

    def eaten(self, lead_x: int, lead_y: int) -> bool:
        return lead_x == self.x and lead_y == self.y


@dataclass
class Fruits:
    fruits: List[Fruit]

    def __init__(self, number_of_fruits: int, snakes: (List, List, List, List)):
        self.fruits = [Fruit(snakes) for _ in range(number_of_fruits)]

    def update(self, snakes: (List, List, List, List), always: bool = False) -> bool:
        # self.fruits = [Fruit(snakes) if random.randint(0, 500) == 0 else fruit for fruit in self.fruits]
        new_fruits = []
        for fruit in self.fruits:
            if always or random.randint(0, 500) == 0:
                new_fruits.append(Fruit(snakes))
            else:
                new_fruits.append(fruit)
        has_changed = self.fruits != new_fruits
        self.fruits = new_fruits
        return has_changed

    def draw(self, screen: Surface):
        for fruit in self.fruits:
            fruit.draw(screen)

    def eat(self, lead_x, lead_y, snakes: (List, List), level) -> int:  ## how much energy was eaten
        energy = 0
        new_fruits = []
        for fruit in self.fruits:
            if fruit.eaten(lead_x, lead_y):
                energy += fruit.energy(level)
                new_fruits.append(Fruit(snakes))
                eat.play()
            else:
                new_fruits.append(fruit)

        self.fruits = new_fruits
        return energy


def choose_colour(snake_list, snake_list2, fruits: Fruits, tick, snekcolour, snekcolour2, colour) \
        -> (Fruits, int, int, int, int):
    # settings['current_fruit']
    change_colour = fruits.update((snake_list, snake_list2))
    if change_colour:
        tick += 0.75
        colour += 1
        if colour == 7:
            colour = 1
        if colour == 1:
            snekcolour = purple
            snekcolour2 = blue
        elif colour == 2:
            snekcolour = blue
            snekcolour2 = green
        elif colour == 3:
            snekcolour = green
            snekcolour2 = yellow
        elif colour == 4:
            snekcolour = yellow
            snekcolour2 = orange
        elif colour == 5:
            snekcolour = orange
            snekcolour2 = red
        elif colour == 6:
            snekcolour = red
            snekcolour2 = purple
    return fruits, tick, snekcolour, snekcolour2, colour
