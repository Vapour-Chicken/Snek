from typing import List

import pygame, time, random
from pygame import Surface
import json
from os.path import exists
from Main.globals import *
from Main.fruit import *

# snake size

# font
smallfont = pygame.font.SysFont("arial.ttf", 25)
mediumfont = pygame.font.SysFont("arial.ttf", 38)
largefont = pygame.font.SysFont("arial.ttf", 50)
giantfont = pygame.font.SysFont("arial.ttf", 75)


def clear_screen():
    screen.fill(black)
    # pygame.draw.rect(screen, black, [0, 0, maxx, maxy])
    pygame.display.flip()


# user messages
def message_to_screen(msg: str, color: object, height: object, font: object):
    screen_text = font.render(msg, True, color)  # Setup font with message
    textRect = screen_text.get_rect()  # Get the size of the text rectangle
    textRect.center = (maxx / 2), ((maxy / 2) - height)  # Setup the centre point
    screen.blit(screen_text, textRect)  # Place the text on the display


def message_to_screen_x(msg: object, color: object, height: object, length: object, font: object) -> object:
    screen_text = font.render(msg, True, color)  # Setup font with message
    textRect = screen_text.get_rect()  # Get the size of the text rectangle
    textRect.center = (maxx / 2) - length, ((maxy / 2) - height)  # Setup the centre point
    screen.blit(screen_text, textRect)  # Place the text on the display


def level_to_str(level: int) -> str:
    level_strings = ["Baby", "Basic Boi", "Hardcore Gamer", "oH mY gOd It BuRnS", "oH mY gOd It BuRnS"]
    return level_strings[level]


def show_menu(settings: dict, music_muted: bool) -> (bool, bool):
    clear_screen()
    music.stop()
    menu_music.play()
    menu = True

    colour_random = [purple, blue, yellow, orange, red]

    while menu:
        screen_colour = black
        current_level = settings['current_level']
        number_of_fruits = settings['number_of_fruits']
        if current_level == 4:
            rand_screen = random.randint(0, 4)
            screen_colour = colour_random[rand_screen]
        screen.fill(screen_colour)
        if music_muted:
            is_muted = "unmute"
        elif not music_muted:
            is_muted = "mute"
            menu_music.set_volume(0.2)
        message_to_screen("SNEK", green, 250, giantfont)
        message_to_screen("Press R for how to play", white, 175, mediumfont)
        message_to_screen(f"Press D to chose difficulty (Current = {level_to_str(current_level)})", white, 100,
                          mediumfont)
        message_to_screen(f"Press A to choose amount of fruits (Current = {number_of_fruits}).", white, -50, mediumfont)
        message_to_screen(f"Press K to choose amount of players (Current = {settings['player_count'] + 1}).", white,
                          -125, mediumfont)
        message_to_screen("Press G to start", white, -200, largefont)
        message_to_screen("Press P to quit.", white, -275, mediumfont)
        message_to_screen("Snek© Copyright William Wyles.", green, -400, largefont)
        message_to_screen("Menu Music by Ov Moi Omm©.", green, -450, smallfont)
        message_to_screen_x(f"M to {is_muted} music.", white, -475, 375, mediumfont)

        if len(settings['topten']) > 0:
            message_to_screen(f"Highest Score is {settings['topten'][0]} - (H)", white, 25, mediumfont)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False, music_muted
            # tests if a key is pressed
            elif event.type == pygame.KEYDOWN:
                # tests which key is pressed
                if event.key == pygame.K_r:
                    click.play()
                    if not rules(screen_colour):
                        return False, music_muted
                elif event.key == pygame.K_h:
                    click.play()
                    if not wall_of_fame(settings, screen_colour):
                        return False, music_muted
                elif event.key == pygame.K_a:
                    click.play()
                    should_continue, number_of_fruits = fruit_chose(screen_colour, number_of_fruits)
                    settings['number_of_fruits'] = number_of_fruits
                elif event.key == pygame.K_d:
                    click.play()
                    level_colour = black
                    if not screen_colour == black:
                        level_colour = purple

                    should_continue, current_level = pick_level(level_colour, current_level)
                    if not should_continue:
                        return False, music_muted

                    settings['current_level'] = current_level

                elif event.key == pygame.K_g:
                    click.play()
                    menu = False
                elif event.key == pygame.K_k:
                    click.play()
                    should_continue, player_count = choose_player(settings, screen_colour)
                    if not should_continue:
                        return False, music_muted
                    settings['player_count'] = player_count
                elif event.key == pygame.K_p:
                    click.play()
                    return False, music_muted
                elif event.key == pygame.K_m:
                    music_muted = not music_muted
                    if music_muted:
                        menu_music.set_volume(0)
                    elif not music_muted:
                        menu_music.set_volume(0.2)
        clock.tick(10)
    menu_music.stop()
    return True, music_muted


def pick_level(screen_colour, current_level) -> (bool, int):
    screen.fill(screen_colour)
    in_menu = True
    while in_menu:
        message_to_screen(f"Press 1 For {level_to_str(0)} Difficulty", green, 200, mediumfont)
        message_to_screen(f"Press 2 For {level_to_str(1)} Difficulty", yellow, 100, mediumfont)
        message_to_screen(f"Press 3 For {level_to_str(2)} Difficulty", orange, 0, mediumfont)
        message_to_screen(f"Press 4 For {level_to_str(3)} Difficulty", red, -100, mediumfont)
        message_to_screen(f"Press 5 For {level_to_str(3)} (No flashing colours)Difficulty", red, -200,
                          mediumfont)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False, current_level
            # tests if a key is pressed
            elif event.type == pygame.KEYDOWN:
                in_menu = False
                clear_screen()
                valid_keys = [
                    {'key': pygame.K_1, 'level': 0},
                    {'key': pygame.K_2, 'level': 1},
                    {'key': pygame.K_3, 'level': 2},
                    {'key': pygame.K_4, 'level': 4},
                    {'key': pygame.K_5, 'level': 3},
                ]
                for rule in valid_keys:
                    if event.key == rule['key']:
                        click.play()
                        return True, rule['level']
    return True, current_level


def rules(screen_colour) -> bool:
    screen.fill(screen_colour)
    in_menu = True
    while in_menu:
        message_to_screen("Use W, A, S, D To move.", white, 200, mediumfont)
        message_to_screen("Eat fruits (different fruits give different energy).", white, 100, mediumfont)
        message_to_screen("If you hit the edge or yourself you die.", white, 0, mediumfont)
        message_to_screen("Have fun.", white, -100, mediumfont)
        message_to_screen("Press B to go back to menu.", white, -200, mediumfont)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            # return False, level, 1
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_b:
                    click.play()
                    in_menu = False
    clear_screen()
    return True


def fruit_chose(screen_colour: int, number_of_fruits: int) -> (bool, int):
    screen.fill(screen_colour)
    in_menu = True
    while in_menu:
        message_to_screen(f"Press 1 For 1 Fruit", white, 200, mediumfont)
        message_to_screen(f"Press 2 For 2 Fruits", white, 100, mediumfont)
        message_to_screen(f"Press 3 For 3 Fruits", white, 0, mediumfont)
        message_to_screen(f"Press 4 For 4 Fruits", white, -100, mediumfont)
        message_to_screen(f"Press 5 For 5 Fruits", white, -200, mediumfont)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            # tests if a key is pressed
            elif event.type == pygame.KEYDOWN:
                clear_screen()
                in_menu = False
                if event.key == pygame.K_1:
                    click.play()
                    number_of_fruits = 1
                elif event.key == pygame.K_2:
                    click.play()
                    number_of_fruits = 2
                elif event.key == pygame.K_3:
                    click.play()
                    number_of_fruits = 3
                elif event.key == pygame.K_4:
                    click.play()
                    number_of_fruits = 4
                elif event.key == pygame.K_5:
                    click.play()
                    number_of_fruits = 5
                elif event.key == pygame.K_HASH:
                    heck.play()
                    number_of_fruits = 500
    return True, number_of_fruits


def wall_of_fame(settings, screen_colour) -> bool:
    clear_screen()
    in_menu = True
    start_pos = -500
    while in_menu:
        screen.fill(screen_colour)
        message_to_screen("Top High scores.", green, 400, giantfont)
        for index, score in enumerate(settings['topten']):
            pos = start_pos - (index * 50)
            message_to_screen(str(score), white, pos, mediumfont)
        if start_pos < 325:
            start_pos += 1
        else:
            message_to_screen("Press B to go back to menu.", white, -300, largefont)
        clock.tick(100)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            # return False, level, 1
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_b:
                    click.play()
                    in_menu = False

    clear_screen()
    return True


def choose_player(settings, screen_colour) -> (bool, int):
    screen.fill(screen_colour)
    player_count = settings['player_count']
    in_menu = True
    while in_menu:
        message_to_screen(f"Press 1 For 1 Player", white, 50, mediumfont)
        message_to_screen(f"Press 2 For 2 Players", white, -50, mediumfont)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            # tests if a key is pressed
            elif event.type == pygame.KEYDOWN:
                clear_screen()
                in_menu = False
                if event.key == pygame.K_1:
                    click.play()
                    player_count = 0
                elif event.key == pygame.K_2:
                    click.play()
                    player_count = 1
    return True, player_count


def draw_rect_alpha(surface, color, rect):
    shape_surf = pygame.Surface(pygame.Rect(rect).size, pygame.SRCALPHA)
    pygame.draw.rect(shape_surf, color, shape_surf.get_rect())
    surface.blit(shape_surf, rect)


def draw_snake(snekcolour, lead_x, lead_y, snake_list):
    tail = pygame.Color(snekcolour[0], snekcolour[1], snekcolour[2], 175)
    pygame.draw.rect(screen, snekcolour, [lead_x, lead_y, block_size, block_size])
    for XnY in snake_list[:-1]:
        draw_rect_alpha(screen, tail, [XnY[0], XnY[1], block_size, block_size])


def run_game(addtick: int, level: int, tick: int, game_music_muted: bool, settings) -> (bool, int, int, bool, bool):
    music.play()
    cheat = False
    snake_list = []
    snake_list2 = []
    number_of_fruits = settings['number_of_fruits']
    snake_length = 1
    snake_length2 = 1
    score = 0
    snekcolour = green
    snekcolour2 = purple
    amomove = 0
    gamExit = False
    show_fruits = False
    move = False
    hecking = False
    colour = 0
    player_count = settings['player_count']
    lead_x_change = 0
    lead_y_change = 0
    lead_x_change2 = 0
    lead_y_change2 = 0
    lead_x = maxx / 2
    lead_y = maxy / 2
    lead_y2 = lead_y
    lead_x2 = lead_x
    if player_count == 1:
        lead_x = maxx / 2 + block_size * 3
        lead_x2 = maxx / 2 - block_size * 3
    snakeHead = [lead_x, lead_y]
    snakeHead2 = [lead_x2, lead_y2]
    fruits = Fruits(number_of_fruits, (snake_list, snake_list2, [snakeHead], [snakeHead2]))

    direction = "none"
    direction2 = "none"
    debug = False

    while not gamExit:
        # event handler
        if game_music_muted:
            is_muted = "unmute"
        elif not game_music_muted:
            is_muted = "mute"
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False, score, amomove, cheat, game_music_muted
            # tests if a key is pressed
            elif event.type == pygame.KEYDOWN:
                if not (event.key == pygame.K_F3 or event.key == pygame.K_e):
                    move = True
                # tests which key is pressed
                if event.key == pygame.K_UP and not direction == "down":
                    lead_y_change = -block_size
                    lead_x_change = 0
                    amomove += 1
                elif event.key == pygame.K_w and not direction == "down" and player_count == 0:
                    lead_y_change = -block_size
                    lead_x_change = 0
                    amomove += 1
                elif event.key == pygame.K_LEFT and not direction == "left":
                    lead_x_change = -block_size
                    lead_y_change = 0
                    amomove += 1
                elif event.key == pygame.K_a and not direction == "left" and player_count == 0:
                    lead_x_change = -block_size
                    lead_y_change = 0
                    amomove += 1
                elif event.key == pygame.K_DOWN and not direction == "up":
                    lead_y_change = block_size
                    lead_x_change = 0
                    amomove += 1
                elif event.key == pygame.K_s and not direction == "up" and player_count == 0:
                    lead_y_change = block_size
                    lead_x_change = 0
                    amomove += 1
                elif event.key == pygame.K_RIGHT and not direction == "right":
                    lead_x_change = block_size
                    lead_y_change = 0
                    amomove += 1
                elif event.key == pygame.K_d and not direction == "right" and player_count == 0:
                    lead_x_change = block_size
                    lead_y_change = 0
                    amomove += 1
                elif event.key == pygame.K_w and not direction2 == "down":
                    lead_y_change2 = -block_size
                    lead_x_change2 = 0
                    amomove += 1
                elif event.key == pygame.K_a and not direction2 == "left":
                    lead_x_change2 = -block_size
                    lead_y_change2 = 0
                    amomove += 1
                elif event.key == pygame.K_s and not direction2 == "up":
                    lead_y_change2 = block_size
                    lead_x_change2 = 0
                    amomove += 1
                elif event.key == pygame.K_d and not direction2 == "right":
                    lead_x_change2 = block_size
                    lead_y_change2 = 0
                    amomove += 1
                elif event.key == pygame.K_F10 and hecking:
                    heck.play()
                    cheat = True
                    snake_length += fruits.eat(lead_x, lead_y, (snake_list, snake_list2, [snakeHead], [snakeHead2]), level)

                    if player_count == 1:
                        snake_length2 += fruits.eat(lead_x2, lead_y2, (snake_list, snake_list2, [snakeHead], [snakeHead]), level)
                elif event.key == pygame.K_F3:
                    debug = not debug
                    click.play()
                    show_fruits = False
                elif event.key == pygame.K_F8 and hecking:
                    heck.play()
                    cheat = True
                    fruits.update((snake_list, snake_list2, [snakeHead], [snakeHead2]), True)
                elif event.key == pygame.K_e:
                    show_fruits = not show_fruits
                    click.play()
                    debug = False
                elif event.key == pygame.K_m:
                    game_music_muted = not game_music_muted
                    if game_music_muted:
                        music.set_volume(0)
                    elif not game_music_muted:
                        music.set_volume(0.5)
        if lead_y_change < 0:
            direction = "up"
        elif lead_y_change > 0:
            direction = "down"
        elif lead_x_change < 0:
            direction = "right"
        elif lead_x_change > 0:
            direction = "left"
        if lead_y_change2 < 0:
            direction2 = "up"
        elif lead_y_change2 > 0:
            direction2 = "down"
        elif lead_x_change2 < 0:
            direction2 = "right"
        elif lead_x_change2 > 0:
            direction2 = "left"

        # ensures the snake cannot leave the screen
        if lead_x + block_size > maxx or lead_x < 0 or lead_y + block_size > maxy or lead_y < 0:
            gamExit = True
        elif lead_x2 + block_size > maxx or lead_x2 < 0 or lead_y2 + block_size > maxy or lead_y2 < 0 and player_count == 1:
            gamExit = True
        # moves the snake
        if move:
            hecking = True
            if lead_x_change == 0 and lead_y_change == 0:
                lead_y_change = -block_size
            if lead_x_change2 == 0 and lead_y_change2 == 0:
                lead_y_change2 = -block_size
            lead_x += lead_x_change
            lead_y += lead_y_change
            if player_count == 1:
                lead_x2 += lead_x_change2
                lead_y2 += lead_y_change2

        snake_length += fruits.eat(lead_x, lead_y, (snake_list, snake_list2, [snakeHead], [snakeHead2]), level)

        if player_count == 1:
            snake_length2 += fruits.eat(lead_x2, lead_y2, (snake_list, snake_list2, [snakeHead], [snakeHead]), level)

        # graphics
        snakeHead = [lead_x, lead_y]
        snake_list.append(snakeHead)
        screen.fill(black)
        if len(snake_list) > snake_length:
            del snake_list[0]

        if player_count == 1:
            snakeHead2 = [lead_x2, lead_y2]
            snake_list2.append(snakeHead2)
            screen.fill(black)
            if len(snake_list2) > snake_length2:
                del snake_list2[0]

        if addtick == 1 and move:
            fruits, tick, snekcolour, snekcolour2, colour = \
                choose_colour(snake_list, snake_list2, fruits, tick, snekcolour, snekcolour2, colour)

        # placing snek
        draw_snake(snekcolour, lead_x, lead_y, snake_list)
        if player_count == 1:
            draw_snake(snekcolour2, lead_x2, lead_y2, snake_list2)
        # apple placement
        fruits.draw(screen)

        # score
        if cheat:
            message_to_screen_x("Cheater", red, -475, -425, mediumfont)
        message_to_screen(str(score), green, -475, mediumfont)
        message_to_screen_x(f"M to {is_muted} music.", white, -475, 375, mediumfont)

        if debug:
            message_to_screen(f"level {level + 1}", green, 475, mediumfont)
            message_to_screen(f"No. fruits {settings['number_of_fruits']}", green, 425, mediumfont)
            message_to_screen(f"length2 {snake_length2}", green, 375, mediumfont)
            message_to_screen(f"length {snake_length}", green, 325, mediumfont)
            message_to_screen(f"addtick {addtick}", green, 275, mediumfont)
        if show_fruits:
            for index, fruit in enumerate(fruits.fruits):
                message_to_screen(f"Energy{index+1} = {fruit.energy(level)}", green, 475 - (50 * index), mediumfont)

        pygame.display.flip()

        # collision
        for eachSegment in snake_list[:-1]:
            if eachSegment == snakeHead:
                gamExit = True
        for eachSegment2 in snake_list2[:-1]:
            if eachSegment2 == snakeHead2:
                gamExit = True
        for eachSegment3 in snake_list[:-1]:
            if eachSegment3 == snakeHead2:
                gamExit = True
        for eachSegment4 in snake_list2[:-1]:
            if eachSegment4 == snakeHead:
                gamExit = True
        # tick the clock
        score = snake_length-1
        clock.tick(tick)

    return gamExit, score, amomove, cheat, game_music_muted


def show_score(score: int, moves_made: int) -> (bool, bool):
    # message of score
    clear_screen()
    finscore = f" You Died. Your score is {score}"
    moves = f"You moved {moves_made} times. Press Q to Go back to Start Menu."
    message_to_screen(finscore, green, 200, largefont)
    message_to_screen(moves, green, -0, largefont)
    message_to_screen("Press R to play again.", green, -200, largefont)
    pygame.display.flip()
    restart = False

    # waiting for exit
    msgexit = False
    while not msgexit:
        # event handler
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False, False
            # tests if a key is pressed
            elif event.type == pygame.KEYDOWN:
                # tests which key is pressed
                if event.key == pygame.K_q:
                    msgexit = True
                if event.key == pygame.K_r:
                    msgexit = True
                    restart = True

        clock.tick(15)
    return True, restart


def main_loop():
    settings_file_name = 'Settings/settings.json'
    settings = {
        'current_level': 0,
        'topten': [],
        'number_of_fruits': 1,
        'player_count': 0
    }
    restart = False
    game_music_muted = False
    music_muted = False
    # read settings
    if exists(settings_file_name):
        with open(settings_file_name) as json_file:
            settings = json.load(json_file)

    # game loop
    while True:
        if not restart:
            should_continue, music_muted = show_menu(settings, music_muted)
            current_level = settings['current_level']

        if not should_continue:
            break
        # we want to run the game
        tick_options = [10, 15, 20, 30, 30]
        tick = tick_options[current_level]
        if current_level == 3 or current_level == 4:
            # make it harder
            addtick = 1
        else:
            addtick = 0

        clear_screen()
        continue_game, score, moves, cheat, game_music_muted = run_game(addtick, current_level, tick, game_music_muted
                                                                        , settings)
        if continue_game:
            if not cheat:  # update settings
                settings['topten'].append(score)
                settings['topten'].sort(reverse=True)
                del settings['topten'][10:]
            continue_game, restart = show_score(score, moves)
            music.stop()
            if not continue_game:
                break
        else:
            break

    # save settings when done
    with open(settings_file_name, 'w') as outfile:
        json.dump(settings, outfile)


main_loop()
quit()
