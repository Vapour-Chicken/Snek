from Main.base import*

main_loop()
quit()